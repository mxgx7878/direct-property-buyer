<?php
$page_title       = 'About | Direct Property Buyer';
$page_description = 'Direct Property Buyer is led by Brad Ghasriani, a senior project manager and property solutions specialist — a calmer, more practical way to sell in Victoria.';
$page_slug        = 'about';
require __DIR__ . '/includes/head.php';
require __DIR__ . '/includes/header.php';
?>
<main id="app">
    <section class="relative bg-navy overflow-hidden">
        <div class="absolute inset-0"><img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1700&q=80" onerror="this.onerror=null;this.src='https://placehold.co/1200x800/0B1F2A/C49A5A?text=Direct+Property+Buyer'" class="w-full h-full object-cover" alt=""></div>
        <div class="absolute inset-0 overlay-grad"></div>
        <div class="relative max-w-7xl mx-auto px-6 pt-16 pb-14 md:pt-24 md:pb-20">
            <nav class="text-xs text-ivory/55 mb-5 flex items-center gap-2 flex-wrap"><a href="index.php" data-link class="hover:text-gold-soft">Home</a> <span>›</span> <span class="text-ivory/80">About</span></nav>
            <div class="mb-5"><span class="eyebrow light">About</span></div>
            <h1 class="font-display text-white text-[2.2rem] sm:text-4xl lg:text-[3.1rem] leading-[1.08] max-w-3xl mb-5">Built by a property and construction professional.</h1>
            <p class="text-ivory/85 text-lg leading-relaxed max-w-2xl mb-8">Direct Property Buyer was created to give Victorian owners a calmer, more practical way to sell — led by hands-on property, renovation and construction experience.</p>
            <div class="flex flex-wrap gap-3"><a href="contact.php" data-link class="btn btn-gold">Request a Free Property Assessment</a><a href="https://wa.me/61421300305?text=Hi%20Direct%20Property%20Buyer%2C%20I'd%20like%20a%20free%2C%20no-obligation%20property%20assessment." target="_blank" rel="noopener" class="btn btn-light">Message Us on WhatsApp</a></div>
        </div>
    </section>
    <!-- ================= MEET BRAD / FAMILY BUSINESS ================= -->
<section class="py-16 md:py-24 bg-ivory">
  <div class="max-w-6xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
    <!-- Photo -->
    <div class="reveal">
      <div class="card overflow-hidden">
        <div class="aspect-[4/5] bg-navy">
          <!-- TODO: drop the client's photo in as /brad-ghasriani.jpg (keep this exact filename and every instance updates at once) -->
          <img src="/brad-ghasriani.jpg"
               onerror="this.onerror=null;this.src='https://placehold.co/900x1100/0B1F2A/C49A5A?text=Brad+Ghasriani'"
               alt="Brad Ghasriani, Founder of Direct Property Buyer"
               class="w-full h-full object-cover">
        </div>
        <div class="p-6">
          <h3 class="font-display text-xl text-navy">Brad Ghasriani</h3>
          <p class="text-sm text-gold-dark font-semibold">Founder &middot; Direct Property Buyer</p>
        </div>
      </div>
    </div>
    <!-- Text -->
    <div class="reveal">
      <div class="mb-4"><span class="eyebrow">Our story</span></div>
      <h2 class="font-display text-3xl md:text-[2.5rem] leading-[1.12] text-navy mb-5">A family business that treats your sale personally</h2>
      <div class="space-y-4 text-ink/75 text-base leading-relaxed">
        <p>Direct Property Buyer is a family-owned and family-run business, founded by Brad Ghasriani. It grew out of years of hands-on experience in property, renovation and construction &mdash; and a simple belief that selling a home should feel calm and considered, never rushed.</p>
        <p>Because we are a family business, every enquiry is handled personally. You deal directly with the people who make the decisions &mdash; not a call centre or a rotating cast of agents &mdash; and your situation is treated with genuine care and discretion.</p>
        <p>Our approach is to understand where you are first, then set out the realistic options &mdash; whether that is selling as-is, renovating before sale, or a direct offer. There is never any pressure to proceed, and your first property assessment is always free.</p>
      </div>
      <div class="flex flex-wrap gap-3 mt-8">
        <a href="contact.php" data-link class="btn btn-gold">Request a Free Property Assessment</a>
        <a href="https://wa.me/61421300305?text=Hi%20Direct%20Property%20Buyer%2C%20I'd%20like%20a%20free%2C%20no-obligation%20property%20assessment." target="_blank" rel="noopener" class="btn btn-outline">Message Us on WhatsApp</a>
      </div>
    </div>
  </div>
</section>
<!-- =============== END MEET BRAD / FAMILY BUSINESS =============== -->
    <section class="py-16 md:py-24 bg-white">
        <div class="max-w-6xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
            <div class="reveal">
                <div>
                    <div class="mb-4"><span class="eyebrow ">Our approach</span></div>
                    <h2 class="font-display text-3xl md:text-[2.5rem] leading-[1.12] text-navy mb-4">Not only a cash buyer</h2>
                </div>
                <div class="mt-6 space-y-4 text-ink/75 text-base leading-relaxed">
                    <p>Many “cash buyer” services offer one thing: a single take-it-or-leave-it number. We think owners deserve more than that.</p>
                    <p>Brad brings real-world property, renovation and construction experience, along with project management know-how. That means we can look at a property practically — what it needs, what it is worth improving, and which path genuinely makes sense for you.</p>
                    <p>Sometimes that is a direct sale. Sometimes it is renovating first. Sometimes it is simply helping you compare your options before making a rushed decision.</p>
                </div>
            </div>
            <div class="reveal">
                <div class="card overflow-hidden">
                    <div class="h-80 bg-navy"><img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=900&q=80" onerror="this.onerror=null;this.src='https://placehold.co/1200x800/0B1F2A/C49A5A?text=Direct+Property+Buyer'" class="w-full h-full object-cover" alt="Brad Ghasriani"></div>
                    <div class="p-6">
                        <h3 class="font-display text-xl text-navy" data-brad-name>Brad Ghasriani</h3>
                        <p class="text-sm text-gold-dark font-semibold mb-2" data-brad-role>Founder, Senior Project Manager | Property Solutions Specialist</p>
                        <p class="text-sm text-ink/65" data-brad-desc>A senior project manager and property solutions specialist with hands-on experience across renovation, construction and project delivery \u2014 helping Victorian owners find the most practical way forward. [Short bio to be finalised with client.]</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-16 md:py-24 bg-ivory">
        <div class="max-w-7xl mx-auto px-6">
            <div class="max-w-3xl mb-12 reveal">
                <div>
                    <div class="mb-4"><span class="eyebrow ">What sets us apart</span></div>
                    <h2 class="font-display text-3xl md:text-[2.5rem] leading-[1.12] text-navy mb-4">Practical, honest, experienced</h2>
                </div>
            </div>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">⌂</span>
                    <h3 class="font-display text-lg text-navy mb-2">Property &amp; renovation experience</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">We understand buildings, not just contracts — including what is worth fixing and what is not.</p>
                </div>
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">◷</span>
                    <h3 class="font-display text-lg text-navy mb-2">Project management know-how</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">Complex situations are managed clearly, with practical next steps.</p>
                </div>
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">✓</span>
                    <h3 class="font-display text-lg text-navy mb-2">Real problem-solving</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">We are comfortable with difficult, stuck or unusual property situations.</p>
                </div>
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">◆</span>
                    <h3 class="font-display text-lg text-navy mb-2">Seller-focused guidance</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">Our starting point is what helps you — not a single fixed offer.</p>
                </div>
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">❖</span>
                    <h3 class="font-display text-lg text-navy mb-2">Options, not pressure</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">We help you compare paths so you can decide with confidence.</p>
                </div>
                <div class="card p-7 reveal"><span class="ico mb-4" aria-hidden="true">☉</span>
                    <h3 class="font-display text-lg text-navy mb-2">Private &amp; respectful</h3>
                    <p class="text-sm text-ink/65 leading-relaxed">A discreet process that treats you and your situation with respect.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="py-16 md:py-24 bg-white">
        <div class="max-w-7xl mx-auto px-6">
            <div class="max-w-3xl mb-12 reveal">
                <div>
                    <div class="mb-4"><span class="eyebrow ">Core values</span></div>
                    <h2 class="font-display text-3xl md:text-[2.5rem] leading-[1.12] text-navy mb-4">What guides how we work</h2>
                </div>
            </div>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">Transparency</h3>
                    <p class="text-sm text-ink/65">Clear, honest communication at every step.</p>
                </div>
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">Practicality</h3>
                    <p class="text-sm text-ink/65">Sensible options grounded in the real numbers.</p>
                </div>
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">Respect</h3>
                    <p class="text-sm text-ink/65">Your circumstances are treated with care and discretion.</p>
                </div>
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">No-pressure guidance</h3>
                    <p class="text-sm text-ink/65">You decide in your own time, never on the spot.</p>
                </div>
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">Speed where suitable</h3>
                    <p class="text-sm text-ink/65">A faster path when timing genuinely matters.</p>
                </div>
                <div class="bg-ivory border border-line rounded-xl p-6 reveal">
                    <div class="w-8 h-1 bg-gold rounded-full mb-4"></div>
                    <h3 class="font-display text-lg text-navy mb-1">Value maximisation where possible</h3>
                    <p class="text-sm text-ink/65">We look for value, where the numbers stack up.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="py-16 bg-ivory">
        <div class="max-w-4xl mx-auto px-6">
            <div class="bg-white border border-line rounded-2xl p-7 reveal">
                <div class="mb-3"><span class="eyebrow">Example scenario · illustrative</span></div>
                <p class="text-ink/75 text-sm leading-relaxed">An owner of a tired, tenanted property facing a tight timeline wanted to avoid a public campaign. After a no-obligation assessment, a direct pathway was agreed with a settlement date that suited their move. <span class="text-ink/50">This is an illustrative example of the type of situation we assist with, not a specific client testimonial.</span></p>
            </div>
        </div>
    </section>
    <section class="relative bg-navy overflow-hidden">
        <div class="absolute inset-0 opacity-20"><img src="https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=1600&q=80" onerror="this.onerror=null;this.src='https://placehold.co/1200x800/0B1F2A/C49A5A?text=Direct+Property+Buyer'" class="w-full h-full object-cover" alt=""></div>
        <div class="absolute inset-0 bg-gradient-to-r from-navy via-navy/95 to-navy/70"></div>
        <div class="relative max-w-5xl mx-auto px-6 py-20 md:py-24 text-center">
            <div class="mb-5"><span class="eyebrow light">Before you decide</span></div>
            <h2 class="font-display text-3xl md:text-[2.6rem] text-white leading-tight mb-5 max-w-3xl mx-auto">Not sure which option suits your situation?</h2>
            <p class="text-ivory/80 text-lg mb-9 max-w-2xl mx-auto">Send us a WhatsApp message and we will respond within 12 hours — no pressure, no obligation.</p>
            <div class="flex flex-wrap gap-3 justify-center"><a href="https://wa.me/61421300305?text=Hi%20Direct%20Property%20Buyer%2C%20I'd%20like%20a%20free%2C%20no-obligation%20property%20assessment." target="_blank" rel="noopener" class="btn btn-gold">Message Us on WhatsApp</a><a href="contact.php" data-link class="btn btn-light">Request Free Assessment</a></div>
        </div>
    </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>